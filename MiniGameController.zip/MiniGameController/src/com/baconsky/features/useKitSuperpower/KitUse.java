package com.baconsky.features.useKitSuperpower;

import org.bukkit.event.player.PlayerInteractEvent ;

public interface KitUse {

	
	public void handleEvent(PlayerInteractEvent event);
	
}
