package com.baconsky.minigame.interfaces;

public enum ScoreboardCommand {
	
	UPDATE_COUNTDOWN,
	
}
