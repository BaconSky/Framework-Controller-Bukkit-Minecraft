package com.baconsky.minigame.interfaces;

public enum FeatureType {
	
	SELECT_KIT,
	USE_KIT,
	SCATTER_CHESTS,
	LOBBY_SCOREBOARD,
	TWO_PHASE_COUNTDOWN,
	SPECTATOR_TEAM,

}
